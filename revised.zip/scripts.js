// const zoomFunc = (type) => {
//   const amts = {
//     in: 10,
//     out: -10,
//   };
//   const d = document.body.style;
//   d.zoom = d.zoom || "125%"; // in case it's an empty string by default
//   d.zoom = (type === "reset" ? 100 : parseInt(d.zoom) + amts[type]) + "%";
// };
// zoomFunc();
